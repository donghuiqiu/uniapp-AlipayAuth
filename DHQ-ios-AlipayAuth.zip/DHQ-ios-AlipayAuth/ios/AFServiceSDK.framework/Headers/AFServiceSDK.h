//
//  AFServiceSDK.h
//  AFServiceSDK
//
//  Created by jiajunchen on 08/01/2018.
//  Copyright © 2018 Alipay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AFServiceSDK.
FOUNDATION_EXPORT double AFServiceSDKVersionNumber;

//! Project version string for AFServiceSDK.
FOUNDATION_EXPORT const unsigned char AFServiceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AFServiceSDK/PublicHeader.h>

#import <AFServiceSDK/AFServiceCenter.h>
#import <AFServiceSDK/AFAuthServiceResponse.h>
