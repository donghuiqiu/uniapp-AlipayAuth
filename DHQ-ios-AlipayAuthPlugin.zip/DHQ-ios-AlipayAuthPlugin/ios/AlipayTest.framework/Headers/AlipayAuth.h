//
//  AlipayTest.h
//  AlipayTest
//
//  Created by simple on 2023/7/20.
//

#import <Foundation/Foundation.h>

#import <DCUniModule.h>

NS_ASSUME_NONNULL_BEGIN

@interface AlipayAuth : DCUniModule

@end

NS_ASSUME_NONNULL_END




